
const { validationResult } = require('express-validator');
const Sale = require('../../models/Sale');
const InventoryItem = require('../../models/InventoryItem');
const FinancialVoucher = require('../../models/FinancialVoucher');
const { pool } = require('../../config/database');
const InvoiceNumberService = require('../../services/invoiceNumberService');
const { isLedgerMigrationComplete } = require('../../services/ledgerMigrationMeta');
const {
  getIdempotentResponse,
  setIdempotentResponse,
} = require('../../utils/idempotencyMemoryCache');
const { getCustomerRunningBalance } = require('../../services/sales/customerRunningBalance');
const { finalizeSettlementSale } = require('../../services/saleLedgerSyncService');
const CustomerLedgerEntries = require('../../services/customerLedgerEntriesService');
const { allowsNegativeStock } = require('../../config/inventory');

const createSale = async (req, res, next) => {
  
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: errors.array()
      });
    }

    const idempotencyKey = req.get('Idempotency-Key') || req.get('idempotency-key');
    const replayBody = getIdempotentResponse(idempotencyKey);
    if (replayBody) {
      res.set('X-Idempotent-Replay', 'true');
      return res.status(200).json(replayBody);
    }

    const { items, scopeType, scopeId, paymentMethod, paymentType, customerInfo, notes, subtotal, tax, discount, total, paymentStatus, status, paymentAmount, creditAmount, creditStatus, outstandingPayments, selectedOutstandingPayments, saleDate } = req.body;

    // Debug: Log the received payment method

    // Validate items
    if (!items || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'At least one item is required'
      });
    }

    // Validate inventory items and enrich item data (skip manual items)
    const enrichedItems = [];
    for (const item of items) {
      if (!item.inventoryItemId) {
        // Manual / clinic service line (no inventory validation)
        let sku = item.sku || null;
        if (!sku && item.clinicServiceId) {
          sku = `CLINIC-${item.clinicServiceId}`;
        }
        if (!sku) sku = `MANUAL-${Date.now()}`;
        const enrichedItem = {
          ...item,
          sku,
          name: item.name || item.itemName,
          unitPrice: item.unitPrice || 0,
          originalPrice: item.originalPrice != null ? item.originalPrice : item.unitPrice || 0,
        };
        enrichedItems.push(enrichedItem);
        continue;
      }
      
      // Validate inventory items
      const inventoryItem = await InventoryItem.findById(item.inventoryItemId);
      if (!inventoryItem) {
        return res.status(400).json({
          success: false,
          message: `Inventory item with ID ${item.inventoryItemId} not found`
        });
      }
      
      // Enrich item with inventory data
      const enrichedItem = {
        ...item,
        sku: item.sku || inventoryItem.sku || `SKU-${item.inventoryItemId}`,
        name: item.name || inventoryItem.name,
        unitPrice: item.unitPrice || inventoryItem.sellingPrice || 0
      };
      
      // Ensure SKU is never null
      if (!enrichedItem.sku) {
        enrichedItem.sku = `SKU-${item.inventoryItemId}`;
      }
      
      
      enrichedItems.push(enrichedItem);
    }

    // Use provided totals or calculate them from items
    let finalSubtotal = parseFloat(subtotal) || 0;
    let finalTax = parseFloat(tax) || 0;
    let finalDiscount = parseFloat(discount) || 0;
    let finalTotal = parseFloat(total) || 0;
    
    // IMPORTANT: Store the bill amount (items total) separately from the net total (which includes credit)
    const billAmount = finalSubtotal + finalTax - finalDiscount; // The actual bill amount

    // Always validate stock for every inventory item regardless of whether totals were provided.
    for (const item of enrichedItems) {
      if (!item.inventoryItemId) continue; // manual items skip stock check
      const inventoryItem = await InventoryItem.findById(item.inventoryItemId);
      if (!inventoryItem) {
        return res.status(400).json({ success: false, message: `Inventory item ${item.inventoryItemId} not found` });
      }
      if (!allowsNegativeStock() && inventoryItem.currentStock < item.quantity) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for ${inventoryItem.name}. Available: ${inventoryItem.currentStock}`
        });
      }
    }

    // If totals are not provided, calculate them from enriched items
    if (subtotal === undefined || subtotal === null || subtotal === '' || tax === undefined || tax === null || tax === '' || total === undefined || total === null || total === '') {
      let calculatedSubtotal = 0;
      let calculatedDiscount = 0;

      for (const item of enrichedItems) {
        const itemTotal = (item.unitPrice * item.quantity) - (item.discount || 0);
        calculatedSubtotal += itemTotal;
        calculatedDiscount += item.discount || 0;
      }

      // No tax applied server-side — POS sends pre-calculated tax; 0 avoids hardcoded 10% mismatch.
      const calculatedTax = parseFloat(tax) || 0;
      const calculatedTotal = calculatedSubtotal + calculatedTax - calculatedDiscount;

      finalSubtotal = calculatedSubtotal;
      finalTax = calculatedTax;
      finalDiscount = calculatedDiscount;
      finalTotal = calculatedTotal;
    }

    // Generate invoice number using branch/warehouse code
    let invoiceNo;
    try {
      // Convert scopeId to number for InvoiceNumberService if it's a string
      const numericScopeId = typeof scopeId === 'string' ? parseInt(scopeId) : scopeId;
      
      // Debug: Check if branch exists and has code
      if (scopeType === 'BRANCH') {
        const [branches] = await pool.execute('SELECT id, name, code FROM branches WHERE id = ?', [numericScopeId]);
        if (branches.length === 0) {
          throw new Error(`Branch not found with ID: ${numericScopeId}`);
        }
        const branch = branches[0];
      }
      
      invoiceNo = await InvoiceNumberService.generateInvoiceNumber(scopeType, numericScopeId);
    } catch (invoiceError) {
      // Fallback to old method if new method fails
      invoiceNo = `INV-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
    }

    // Extract customer name and phone from customerInfo
    // trim values to avoid accidental spaces
    let customerName = customerInfo?.name ? customerInfo.name.trim() : '';
    let customerPhone = customerInfo?.phone ? customerInfo.phone.trim() : '';

    // If the POS terminal puts the phone number into the name field and phone field
    // is blank, treat that value as the phone. Many terminals allow typing the phone
    // directly into the "name" input so we detect numeric-only strings and move
    // them to the phone variable.
    if (!customerPhone && customerName && /^\d+$/.test(customerName)) {
      customerPhone = customerName;
      // clear the name so that the customer record uses a generic name
      // (Walk-in Customer) instead of a numeric string
      customerName = '';
    }

    // Get branch/warehouse name for scope_id
    let scopeName = '';
    if (scopeType === 'BRANCH' && scopeId) {
      const numericScopeId = typeof scopeId === 'string' ? parseInt(scopeId) : scopeId;
      const [branches] = await pool.execute('SELECT name FROM branches WHERE id = ?', [numericScopeId]);
      scopeName = branches[0]?.name || scopeId;
    } else if (scopeType === 'WAREHOUSE' && scopeId) {
      const numericScopeId = typeof scopeId === 'string' ? parseInt(scopeId) : scopeId;
      const [warehouses] = await pool.execute('SELECT name FROM warehouses WHERE id = ?', [numericScopeId]);
      scopeName = warehouses[0]?.name || scopeId;
    } else {
      scopeName = scopeId || '';
    }
    
    // ✅ FIXED: Check if outstanding payments are included in the sale and clear them FIRST
    // Calculate outstanding amount: finalTotal includes outstanding, billAmount is just the sale
    const outstandingAmount = finalTotal - billAmount;
    let settlementCreated = false;
    let settlementAmount = 0;
    let settlementId = null;
    
    if (outstandingAmount > 0.01 && customerName && customerPhone && paymentMethod !== 'FULLY_CREDIT') {
        
        try {
            // Get customer's latest running balance BEFORE settlement
            const balanceBeforeSettlement = await getCustomerRunningBalance(
                customerName,
                customerPhone,
                scopeType,
                scopeName
            );
            
            // The outstanding amount should be cleared
            settlementAmount = Math.min(outstandingAmount, balanceBeforeSettlement);
            
            if (settlementAmount > 0.01) {
                const settlementOldBalance = balanceBeforeSettlement;
                const settlementNewRunningBalance = settlementOldBalance - settlementAmount;
                const settlementPaymentStatus = Math.abs(settlementNewRunningBalance) <= 0.01 ? 'COMPLETED' : 'PARTIAL';
                
                // Generate settlement invoice number
                let settlementInvoiceNo;
                try {
                    const numericScopeId = typeof scopeName === 'string' ? (scopeName.match(/^\d+$/) ? parseInt(scopeName) : scopeName) : scopeName;
                    settlementInvoiceNo = await InvoiceNumberService.generateSettlementNumber(scopeType, numericScopeId);
                } catch (invoiceError) {
                    settlementInvoiceNo = `SETTLE-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
                }
                
                // Create settlement record BEFORE the sale
                const [settlementResult] = await pool.execute(`
                    INSERT INTO sales (
                        invoice_no, scope_type, scope_id, user_id, subtotal, tax, discount, total,
                        payment_method, payment_type, payment_status, customer_info, customer_name, 
                        customer_phone, payment_amount, credit_amount, old_balance, running_balance, credit_status,
                        notes, status, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                `, [
                    settlementInvoiceNo,
                    scopeType,
                    scopeName,
                    req.user.id,
                    0, // subtotal
                    0, // tax
                    0, // discount
                    settlementAmount, // total = payment amount
                    paymentMethod, // Use same payment method as sale
                    'OUTSTANDING_SETTLEMENT',
                    settlementPaymentStatus,
                    JSON.stringify({ name: customerName, phone: customerPhone }),
                    customerName,
                    customerPhone,
                    settlementAmount, // payment_amount
                    0, // credit_amount
                    settlementOldBalance, // old_balance
                    settlementNewRunningBalance, // running_balance
                    'NONE', // credit_status
                    `Outstanding payment settlement (will be followed by sale): Customer paid ${settlementAmount.toFixed(2)}`,
                    'COMPLETED',
                ]);
                
                settlementId = settlementResult.insertId;
                const settlementConn = await pool.getConnection();
                try {
                  await settlementConn.beginTransaction();
                  await finalizeSettlementSale(settlementConn, settlementId);
                  await settlementConn.commit();
                } catch (ledgerErr) {
                  await settlementConn.rollback();
                  throw ledgerErr;
                } finally {
                  settlementConn.release();
                }

                settlementCreated = true;
            }
        } catch (settlementError) {
            return res.status(400).json({
              success: false,
              message: settlementError.message || 'Failed to record outstanding settlement before sale',
            });
        }
    }
    
    // Get customer's current running balance from previous transactions
    // This will be used as old_balance for the new sale
    // If settlement was created, this will include the settlement's running_balance
    const previousRunningBalance = await getCustomerRunningBalance(customerName, customerPhone, scopeType, scopeName);
    const oldBalance = previousRunningBalance; // old_balance = full ledger before this post (posting order = created_at)

    // ✅ CORRECTED: Payment calculation for different scenarios
    let finalPaymentAmount, finalCreditAmount;

    if (paymentMethod === 'FULLY_CREDIT') {
        // Scenario 4: Fully Credit
        // Customer takes items on complete credit
        finalPaymentAmount = 0;
        finalCreditAmount = billAmount;
    } else if (paymentType === 'BALANCE_PAYMENT' || (paymentAmount !== undefined && parseFloat(paymentAmount) === 0 && creditAmount !== undefined)) {
        // NEW SCENARIO: Balance Payment
        // Customer uses their available credit balance (negative outstanding balance)
        // Payment: 0 (no cash paid), Credit: billAmount (uses from balance)
        finalPaymentAmount = 0;
        finalCreditAmount = parseFloat(creditAmount) || billAmount; // Use credit amount from frontend or bill amount
    } else {
        // Handle other payment methods
        const providedPaymentAmount = paymentAmount !== undefined ? parseFloat(paymentAmount) : null;
        const providedCreditAmount = creditAmount !== undefined ? parseFloat(creditAmount) : null;
        
        if (providedPaymentAmount !== null && providedCreditAmount !== null) {
            // Both amounts explicitly provided
            finalPaymentAmount = providedPaymentAmount;
            finalCreditAmount = providedCreditAmount;
        } else if (providedPaymentAmount !== null) {
            // Only payment amount provided - calculate credit
            finalPaymentAmount = providedPaymentAmount;
            finalCreditAmount = billAmount - providedPaymentAmount;
        } else if (providedCreditAmount !== null) {
            // Only credit amount provided - calculate payment
            finalCreditAmount = providedCreditAmount;
            finalPaymentAmount = billAmount - providedCreditAmount;
        } else {
            // No amounts provided - assume full payment (Scenario 1)
            finalPaymentAmount = billAmount;
            finalCreditAmount = 0;
        }
    }

    // ✅ CORRECTED: Handle customer's previous balance (credit/advance payment)
    // Only auto-adjust if amounts weren't explicitly provided by frontend
    const amountsExplicitlyProvided = paymentAmount !== undefined && creditAmount !== undefined;
    
    let adjustedCreditAmount = finalCreditAmount;
    let adjustedPaymentAmount = finalPaymentAmount;

    // Special handling for BALANCE_PAYMENT: Don't adjust, amounts are correct
    if (paymentType === 'BALANCE_PAYMENT') {
        // Keep the amounts as-is - no adjustment needed
        adjustedPaymentAmount = finalPaymentAmount;
        adjustedCreditAmount = finalCreditAmount;
    } else if (previousRunningBalance < 0 && !amountsExplicitlyProvided) {
        // Customer has advance credit - use it for this purchase (only if amounts weren't explicitly set)
        const availableCredit = Math.abs(previousRunningBalance);
        
        
        if (billAmount <= availableCredit) {
            // Entire purchase can be covered by existing credit
            adjustedPaymentAmount = 0;
            adjustedCreditAmount = -billAmount; // Negative credit means using advance credit
        } else {
            // Part of purchase covered by credit, rest by payment
            adjustedPaymentAmount = billAmount - availableCredit;
            adjustedCreditAmount = -availableCredit; // Negative credit means using advance credit
        }
        
    } else if (previousRunningBalance < 0 && amountsExplicitlyProvided) {
    }

    // Use adjusted amounts
    finalPaymentAmount = adjustedPaymentAmount;
    finalCreditAmount = adjustedCreditAmount;

    // ✅ FIX: When customer has negative balance (credit) and makes a purchase,
    // we need to use the credit to reduce the bill amount
    // Example: Customer has -200 credit, buys 700, pays 500
    // Credit used: 200, Net bill: 500, Payment: 500, New credit: 0, New balance: 0
    
    let creditUsedFromPreviousBalance = 0;
    let adjustedBillAmount = billAmount;
    
    // If customer has credit (negative balance), use it to reduce the bill
    if (previousRunningBalance < 0) {
        const availableCredit = Math.abs(previousRunningBalance);
        creditUsedFromPreviousBalance = Math.min(availableCredit, billAmount);
        adjustedBillAmount = billAmount - creditUsedFromPreviousBalance;
        
    }
    
    // Calculate running balance for this transaction
    // running_balance = previous_balance + (bill_amount - payment_amount)
    // This means: balance increases by unpaid amount (credit given)
    // OR: balance decreases by payment amount (debt paid)
    // BUT: If we used credit, we need to account for that
    const newCreditAmount = adjustedBillAmount - finalPaymentAmount;
    const runningBalance = previousRunningBalance + creditUsedFromPreviousBalance + newCreditAmount;

    // Helper function to identify payment scenario
    function getPaymentScenario(payment, credit, bill) {
        if (payment === bill && credit === 0) return 'Full Payment';
        if (payment === 0 && credit === bill) return 'Fully Credit';
        if (payment > 0 && credit > 0 && payment + credit === bill) return 'Partial Payment';
        if (credit < 0) return 'Using Customer Credit';
        return 'Mixed Scenario';
    }

    // ✅ CORRECTED: Payment validation for all scenarios
    let isValid = true;
    let errorMessage = '';

    // Calculate the actual amount that needs to be covered
    // Use finalTotal (which includes outstanding balance) instead of billAmount (cart only)
    const amountToCover = finalTotal; // This includes outstanding balance from frontend
    

    if (finalCreditAmount < 0) {
        // Customer is using advance credit OR overpaying (negative credit amount)
        // Example: Payment: 7000, Credit: -5900, Bill: 5400
        // Validation: 7000 + (-5900) = 1100 ❌ BUT net amount (5400) is already paid via credit
        // ACTUALLY: frontend sends paymentAmount + creditAmount = totalWithOutstanding
        // So validation should check against finalTotal (not billAmount)
        const totalCoverage = finalPaymentAmount + finalCreditAmount; // Don't use Math.abs!
        isValid = Math.abs(totalCoverage - finalTotal) <= 0.01;
        errorMessage = `Payment (${finalPaymentAmount}) + credit (${finalCreditAmount}) must equal total amount (${finalTotal})`;
        
    } else {
        // Normal case: payment + credit should equal total amount (including outstanding)
        const totalCoverage = finalPaymentAmount + finalCreditAmount;
        isValid = Math.abs(totalCoverage - finalTotal) <= 0.01;
        errorMessage = `Payment amount (${finalPaymentAmount}) + credit amount (${finalCreditAmount}) must equal total amount (${finalTotal})`;
        
    }

    if (!isValid) {
        return res.status(400).json({
            success: false,
            message: errorMessage
        });
    }
    
    // ✅ CORRECTED: Enhanced payment status logic
    let finalPaymentStatus;
    if (paymentStatus) {
        // Use provided status if valid
        finalPaymentStatus = paymentStatus;
    } else if (paymentType === 'BALANCE_PAYMENT') {
        // Balance payment: Customer uses credit balance - payment is COMPLETED using credit
        finalPaymentStatus = 'COMPLETED';
    } else if (paymentMethod === 'FULLY_CREDIT') {
        finalPaymentStatus = 'PENDING';  // Fully credit sales are PENDING
    } else if (finalCreditAmount > 0) {
        finalPaymentStatus = 'PENDING';  // Customer still owes money
    } else if (finalCreditAmount < 0) {
        // Customer used advance credit - payment is COMPLETED but they have new credit
        finalPaymentStatus = 'COMPLETED';
    } else {
        // Credit amount is 0 - payment is exactly balanced
        finalPaymentStatus = 'COMPLETED';
    }

    
    // Determine credit status
    // Credit status should be 'PENDING' if credit exists (positive or negative)
    const finalCreditStatus = creditStatus || ((finalCreditAmount > 0 || finalCreditAmount < 0) ? 'PENDING' : 'NONE');
    
    // Validate payment amounts (allow negative for overpayments creating advance credit)
    // Only block invalid scenarios: paymentAmount is negative but total is positive
    if (finalPaymentAmount < 0 && finalTotal > 0) {
        return res.status(400).json({
            success: false,
            message: 'Payment amount cannot be negative when total is positive'
        });
    }
    
    // Validate partial payment logic
    if (finalPaymentStatus === 'PARTIAL' && finalCreditAmount <= 0) {
        return res.status(400).json({
            success: false,
            message: 'Partial payment requires a credit amount greater than 0'
        });
    }
    
    if (finalPaymentStatus === 'COMPLETED' && finalCreditAmount > 0) {
        return res.status(400).json({
            success: false,
            message: 'Completed payment cannot have a credit amount'
        });
    }
    
    
    // Create customer record if customer name/phone is provided and doesn't exist
let customerId = null;
    if (customerName || customerPhone) {
        try {

            // ── Resolve the NUMERIC scope IDs ────────────────────────────────
            // customers table uses branch_id (int) and warehouse_id (int), NOT names.
            let resolvedBranchId    = null;
            let resolvedWarehouseId = null;

            if (scopeType === 'BRANCH') {
                // scopeId coming from POS is always the numeric branch ID
                if (typeof scopeId === 'number') {
                    resolvedBranchId = scopeId;
                } else if (typeof scopeId === 'string' && /^\d+$/.test(scopeId)) {
                    resolvedBranchId = parseInt(scopeId);
                } else {
                    // scopeId is a name string — resolve to ID
                    const [rows] = await pool.execute('SELECT id FROM branches WHERE name = ? LIMIT 1', [scopeId]);
                    resolvedBranchId = rows[0]?.id || null;
                }
            } else if (scopeType === 'WAREHOUSE') {
                if (typeof scopeId === 'number') {
                    resolvedWarehouseId = scopeId;
                } else if (typeof scopeId === 'string' && /^\d+$/.test(scopeId)) {
                    resolvedWarehouseId = parseInt(scopeId);
                } else {
                    const [rows] = await pool.execute('SELECT id FROM warehouses WHERE name = ? LIMIT 1', [scopeId]);
                    resolvedWarehouseId = rows[0]?.id || null;
                }
            }

            // ── Lookup strategy ──────────────────────────────────────────────
            // Uniqueness rule:  scope (branch_id OR warehouse_id)  +  phone
            // • Same phone in branch 1 and branch 2 → two DIFFERENT customers ✓
            // • Same name in same branch             → same customer (if phone matches) ✓
            // • No phone provided                    → fall back to name-only within scope
            let existingCustomers = [];

            if (customerPhone && (resolvedBranchId || resolvedWarehouseId)) {
                // PRIMARY lookup: scope + phone  (the true unique key)
                if (resolvedBranchId) {
                    const [rows] = await pool.execute(
                        'SELECT id, name, phone FROM customers WHERE phone = ? AND branch_id = ? LIMIT 1',
                        [customerPhone, resolvedBranchId]
                    );
                    existingCustomers = rows;
                } else {
                    const [rows] = await pool.execute(
                        'SELECT id, name, phone FROM customers WHERE phone = ? AND warehouse_id = ? LIMIT 1',
                        [customerPhone, resolvedWarehouseId]
                    );
                    existingCustomers = rows;
                }
            } else if (customerPhone) {
                // Phone provided but scope not resolved — fallback: phone only
                const [rows] = await pool.execute(
                    'SELECT id, name, phone FROM customers WHERE phone = ? LIMIT 1',
                    [customerPhone]
                );
                existingCustomers = rows;
            } else if (customerName && (resolvedBranchId || resolvedWarehouseId)) {
                // No phone — use name within scope as fallback
                if (resolvedBranchId) {
                    const [rows] = await pool.execute(
                        'SELECT id, name, phone FROM customers WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) AND branch_id = ? LIMIT 1',
                        [customerName, resolvedBranchId]
                    );
                    existingCustomers = rows;
                } else {
                    const [rows] = await pool.execute(
                        'SELECT id, name, phone FROM customers WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) AND warehouse_id = ? LIMIT 1',
                        [customerName, resolvedWarehouseId]
                    );
                    existingCustomers = rows;
                }
            }

            if (existingCustomers.length === 0) {
                // ── Create new customer ──────────────────────────────────────
                const customerData = {
                    name:            customerName || 'Walk-in Customer',
                    email:           customerInfo?.email   || '',
                    phone:           customerPhone         || '',
                    address:         customerInfo?.address || '',
                    city:            '',
                    state:           '',
                    zip_code:        '',
                    customer_type:   'INDIVIDUAL',
                    credit_limit:    0.00,
                    current_balance: finalCreditAmount || 0.00,
                    payment_terms:   'CASH',
                    branch_id:       resolvedBranchId,
                    warehouse_id:    resolvedWarehouseId,
                    status:          'ACTIVE',
                    notes:           'Auto-created from POS sale',
                    created_at:      new Date(),
                    updated_at:      new Date()
                };

                const [customerResult] = await pool.execute(`
                    INSERT INTO customers (
                        name, email, phone, address, city, state, zip_code,
                        customer_type, credit_limit, current_balance, payment_terms,
                        branch_id, warehouse_id, status, notes, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `, [
                    customerData.name,
                    customerData.email,
                    customerData.phone,
                    customerData.address,
                    customerData.city,
                    customerData.state,
                    customerData.zip_code,
                    customerData.customer_type,
                    customerData.credit_limit,
                    customerData.current_balance,
                    customerData.payment_terms,
                    customerData.branch_id,
                    customerData.warehouse_id,
                    customerData.status,
                    customerData.notes,
                    customerData.created_at,
                    customerData.updated_at
                ]);

                customerId = customerResult.insertId;
            } else {
                // ── Reuse existing customer ──────────────────────────────────
                customerId = existingCustomers[0].id;

                const migrationDoneForCustomer = await isLedgerMigrationComplete(pool);
                if (migrationDoneForCustomer && scopeType && scopeName) {
                  const ledgerBal = await CustomerLedgerEntries.getCustomerBalance(pool, {
                    scopeType,
                    scopeId: scopeName,
                    retailerId: null,
                    customerName: customerName || '',
                    customerPhone: customerPhone || '',
                  });
                  await pool.execute(
                    'UPDATE customers SET current_balance = ?, updated_at = NOW() WHERE id = ?',
                    [ledgerBal, customerId]
                  );
                } else if (finalCreditAmount > 0) {
                  await pool.execute(
                    'UPDATE customers SET current_balance = current_balance + ?, updated_at = NOW() WHERE id = ?',
                    [finalCreditAmount, customerId]
                  );
                }
            }
        } catch (customerError) {
            // Don't fail the sale if customer logic fails
        }
    }

    // Create sale
    const saleData = {
        invoiceNo: invoiceNo || null,
        scopeType: scopeType || null,
        scopeId: scopeName || scopeId || null,
        userId: req.user.id || null,
        userName: req.user.name || req.user.username || null,
        userRole: req.user.role || null,
        shiftId: req.body.shiftId || req.currentShift?.id || null,
        subtotal: finalSubtotal || 0,
        tax: finalTax || 0,
        discount: finalDiscount || 0,
        total: billAmount || 0, // ✅ Use bill amount, not final total with credit adjustments
        paymentMethod: paymentMethod || null,
        paymentType: paymentType || null,
        paymentStatus: finalPaymentStatus || null,
        customerInfo: customerInfo ? JSON.stringify(customerInfo) : null,
        customerName: customerName || null,
        customerPhone: customerPhone || null,
        customerId: customerId,
        paymentAmount: finalPaymentAmount || 0,
        creditAmount: finalCreditAmount || 0,
        oldBalance: oldBalance || 0, // ✅ Save old_balance (previous row's running_balance)
        runningBalance: runningBalance || 0, // ✅ Save running_balance (old_balance + amount - payment)
        creditStatus: finalCreditStatus || 'NONE',
        creditDueDate: finalCreditAmount > 0 ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) : null,
        notes: notes || null,
        saleDate: saleDate || null,
        status: status || 'COMPLETED',
        items: enrichedItems.map(item => ({
            inventoryItemId: item.inventoryItemId || null,
            sku: item.sku || null,
            name: item.name || null,
            quantity: item.quantity || 0,
            unitPrice: item.unitPrice || 0,
            originalPrice: item.originalPrice || item.unitPrice || 0,
            discount: item.discount || 0,
            discountType: item.discountType || 'amount',
            total: (item.unitPrice * item.quantity) - (item.discount || 0)
        }))
    };

    // Validate required fields before creating sale
    if (!req.user.id) {
        return res.status(400).json({
            success: false,
            message: 'User ID is required'
        });
    }

    if (!scopeType) {
        return res.status(400).json({
            success: false,
            message: 'Scope type is required'
        });
    }

    if (!scopeName) {
        return res.status(400).json({
            success: false,
            message: 'Scope ID/Name is required'
        });
    }

    if (!paymentMethod) {
        return res.status(400).json({
            success: false,
            message: 'Payment method is required'
        });
    }

    // Final validation - ensure no null SKUs
    for (const item of saleData.items) {
        if (!item.sku) {
            return res.status(400).json({
                success: false,
                message: `SKU is required for item ${item.inventoryItemId}`,
                item: item
            });
        }
    }

    
    let sale;
    try {
        sale = await Sale.create(saleData);
    } catch (saleError) {
        // If a settlement was committed before Sale.create, reverse it now so
        // the AR ledger stays consistent (settlement with no corresponding sale).
        if (settlementCreated && settlementId) {
          try {
            const { removeSaleFromLedgers } = require('../../services/saleLedgerSyncService');
            const cleanConn = await pool.getConnection();
            try {
              await cleanConn.beginTransaction();
              const [settlRow] = await cleanConn.execute('SELECT * FROM sales WHERE id = ? LIMIT 1', [settlementId]);
              if (settlRow.length) await removeSaleFromLedgers(cleanConn, settlementId, settlRow[0]);
              await cleanConn.execute('DELETE FROM sales WHERE id = ?', [settlementId]);
              await cleanConn.commit();
            } catch (_) {
              await cleanConn.rollback();
            } finally {
              cleanConn.release();
            }
          } catch (_) { /* best-effort */ }
        }
        throw saleError;
    }

    // Stock + GL chart-of-accounts: handled inside Sale.create (single transaction; GL failure rolls back sale)

    if (customerId && (await isLedgerMigrationComplete(pool)) && scopeType && scopeName) {
      try {
        const ledgerBal = await CustomerLedgerEntries.getCustomerBalance(pool, {
          scopeType,
          scopeId: scopeName,
          retailerId: sale?.retailerId ?? sale?.retailer_id ?? null,
          customerName: customerName || '',
          customerPhone: customerPhone || '',
        });
        await pool.execute(
          'UPDATE customers SET current_balance = ?, updated_at = NOW() WHERE id = ?',
          [ledgerBal, customerId]
        );
      } catch (syncErr) {
      }
    }

    // ✅ FIX: Clear/reduce old credit balance in previous sales when credit is used
    // Immutable ledger: never mutate historical sales.running_balance — ledger is source of truth.
    if (
      creditUsedFromPreviousBalance > 0 &&
      (customerName || customerPhone) &&
      !(await isLedgerMigrationComplete(pool))
    ) {
        try {
            
            // Get connection for transaction
            const connection = await pool.getConnection();
            try {
                await connection.beginTransaction();
                
                // Find sales with negative running balance (credit) for this customer
                let query = `
                    SELECT id, invoice_no, credit_amount, running_balance, payment_status, scope_type, scope_id
                    FROM sales 
                    WHERE (customer_name = ? OR customer_phone = ?)
                      AND running_balance < 0
                `;
                
                const queryParams = [customerName, customerPhone];
                
                // Add scope filtering for non-admin users
                if (req.user.role !== 'ADMIN' && scopeName && scopeType) {
                    query += ' AND scope_type = ? AND (scope_id = ? OR scope_id = CAST(? AS CHAR))';
                    queryParams.push(scopeType, scopeName, scopeName);
                }
                
                query += ' ORDER BY created_at ASC';
                
                const [creditSales] = await connection.execute(query, queryParams);
                
                let remainingCreditToClear = creditUsedFromPreviousBalance;
                const processedSales = [];
                
                // Process each credit sale to clear the credit
                for (const creditSale of creditSales) {
                    if (remainingCreditToClear <= 0) break;
                    
                    const currentCredit = Math.abs(parseFloat(creditSale.running_balance));
                    const creditToClear = Math.min(remainingCreditToClear, currentCredit);
                    
                    // Update the sale's running balance and credit amount
                    const newRunningBalance = parseFloat(creditSale.running_balance) + creditToClear;
                    const newCreditAmount = parseFloat(creditSale.credit_amount) + creditToClear;
                    const newPaymentStatus = newRunningBalance >= 0 ? 'COMPLETED' : creditSale.payment_status;
                    
                    await connection.execute(
                        `UPDATE sales 
                         SET credit_amount = ?, 
                             running_balance = ?,
                             payment_status = ?,
                             updated_at = NOW()
                         WHERE id = ?`,
                        [newCreditAmount, newRunningBalance, newPaymentStatus, creditSale.id]
                    );
                    
                    processedSales.push({
                        saleId: creditSale.id,
                        invoiceNo: creditSale.invoice_no,
                        creditCleared: creditToClear,
                        remainingRunningBalance: newRunningBalance,
                        newStatus: newPaymentStatus
                    });
                    
                    remainingCreditToClear -= creditToClear;
                    
                }
                
                await connection.commit();
                
            } catch (clearError) {
                await connection.rollback();
                // Don't fail the sale if credit clearing fails, but log it
            } finally {
                connection.release();
            }
        } catch (error) {
            // Don't fail the sale if credit clearing fails
        }
    }

    // Create financial voucher for the sale
    try {
        const voucherNo = `VCH-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
        const voucherData = {
            voucherNo: voucherNo,
            type: 'INCOME',
            category: 'SALES',
            paymentMethod: paymentMethod.toUpperCase(),
            amount: billAmount, // ✅ Use bill amount for voucher
            description: `Sale from POS Terminal - ${scopeType}: ${scopeName}`,
            reference: invoiceNo,
            scopeType: scopeType,
            scopeId: scopeId,
            userId: req.user.id,
            userName: req.user.name,
            userRole: req.user.role,
            status: 'APPROVED', // Auto-approve sales from POS
            approvedBy: req.user.id,
            approvalNotes: null,
            rejectionReason: null
        };

        await FinancialVoucher.create(voucherData);
    } catch (voucherError) {
        // Don't fail the sale if voucher creation fails
    }

    const responseBody = {
        success: true,
        message: 'Sale created successfully',
        data: {
            ...sale,
            invoice_no: sale.invoiceNo  // Add snake_case version for frontend compatibility
        }
    };
    if (idempotencyKey) {
      setIdempotentResponse(idempotencyKey, responseBody);
    }
    res.status(201).json(responseBody);
  } catch (error) {
    
    res.status(500).json({
        success: false,
        message: 'Error creating sale',
        error: error.message,
        errorCode: error.code,
        sqlMessage: error.sqlMessage,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
};
module.exports = { createSale };
